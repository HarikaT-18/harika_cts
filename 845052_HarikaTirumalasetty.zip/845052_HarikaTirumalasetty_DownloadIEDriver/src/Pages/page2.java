package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;

public class page2 
{
	WebDriver dr; //initalizing webdriver element
	libraries e;
	
	public page2(WebDriver dr) //Creating constructor class
	{
		this.dr=dr;
		e=new libraries(dr); //creating object for utilites class
	}
	
	
	By windows_IE=By.xpath("/html/body/div[2]/div[2]/p/a[2]"); //xpath for 64 bit windows IE
	
	public void clk_IE()
	{
		WebElement we=e.Clickable(windows_IE, 20);
		we.click();
	}
	
	public void operation2() //creating method for clicking IEDriver server
	{
		this.clk_IE();
	}

}
