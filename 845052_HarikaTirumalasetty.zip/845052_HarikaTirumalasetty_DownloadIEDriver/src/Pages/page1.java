package Pages;

import java.io.InterruptedIOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;

public class page1 
{
	WebDriver dr;  //initalizing webdriver element  
	libraries e;   //initalizing libraries element
	
	public  page1(WebDriver dr)//creating constructor class
	{
		this.dr=dr;
		e=new libraries(dr);//creating object for utilites class
	}
		
	By download=By.xpath("//*[@id=\"navbar\"]/a[1]"); //xpath for downloading
	
	
	public void clk_dwld() throws InterruptedException 
	{
		WebElement wait=e.Clickable(download,50);
		wait.click();

	}
	
	public void operation1() //creating method for click on downloads
	{
		try
		{
			this.clk_dwld();
		} 
		catch (InterruptedException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
