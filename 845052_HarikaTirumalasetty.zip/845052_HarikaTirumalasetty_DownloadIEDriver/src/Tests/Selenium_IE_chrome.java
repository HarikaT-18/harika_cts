package Tests;

import org.testng.annotations.Test;

import Pages.page1;
import Pages.page2;


import org.testng.annotations.BeforeClass;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

public class Selenium_IE_chrome 
{
	static WebDriver dr; //Initalizing webdriver element
	protected static ChromeOptions options; //Initalizing chromeoptins
	String downloadpath;	
	page1 dwld; 
	page2 IEdriver;
	
  @Test(priority=0)
  public void creating_downloadpath_directory() throws InterruptedException
  {
	  
	  downloadpath=System.getProperty("user.dir")+File.separator + "downloads";
	  System.out.println(downloadpath);
	  Map<String,String> prefs=new HashMap<String,String>(); //setting download path directory
	  prefs.put("download.default_directory",downloadpath);
	  options=new ChromeOptions();//creating object
	  options.setExperimentalOption("prefs", prefs);
  }
  @Test(priority=1)//test method for launching browser
  public void launchingbrowser() throws InterruptedException
  {
	 
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  dr=new ChromeDriver(options);
	  dr.get("https://www.selenium.dev/");//passing url to webdriver element
	  dr.manage().window().maximize();//maximizing the window
	  dr.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	  
		
  }

  @Test(priority=2)  //test method for assertion and calling page1 and page2
  public void operations() throws InterruptedException
  {
	  dwld=new page1(dr);//object creation for page1
	  dwld.operation1();//calling operation1 method in page1 class
	  IEdriver=new page2(dr);//object creation for page2
	  IEdriver.operation2();//calling operation2 method in page2 class
	  Thread.sleep(20000);
	  File f=new File(downloadpath+"\\IEDriverServer_x64_3.150.1.zip");
	  boolean check=f.exists();
	  if(check==true)
	  {
		  Assert.assertTrue(check, "IE Driver Downloaded !!!");
	  }
	  else
	  {
		  Assert.assertTrue(check, "IE Driver Not downloaded !!!");
	  }
	  
  }
  @Test(priority=3)//test method for closing browser
  public void closing_browser() 
  {
	  dr.close();
  }

}
