package utilites;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class libraries 
{
	WebDriver dr;
	
	public libraries(WebDriver dr)
	{
		this.dr=dr;
	}
	
	
	public WebElement Clickable(By locator,int timeout) 
	{
		WebElement e= null;
		try 
		{
			WebDriverWait p= new WebDriverWait(dr,timeout);
			e=p.until(ExpectedConditions.elementToBeClickable(locator));
			System.out.println("Element located");
		}
		catch(Exception f) 
		{
			System.out.println("element not located");
		}
		return e;
	}
	
	

}
