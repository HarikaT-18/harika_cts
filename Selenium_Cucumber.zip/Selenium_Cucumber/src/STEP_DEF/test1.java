package STEP_DEF;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1
{
	WebDriver dr;
	String a_title;
	String e_title="Demo Web Shop";
	String testresult;
	//String a_email;
	//String x= "//div[@class='header-links']//child::li[1]";
	//String e_email="tirumalashetty.harika@gmail.com";
	
	@Given("^Browser is launched & login page displayed$")
	public void browser_is_launched_login_page_displayed() throws Throwable {
	  System.out.println(" browser is launched & login page displayed");
	  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	  dr=new ChromeDriver();
	  dr.get("http://demowebshop.tricentis.com");
		
	}

	@When("^User enters login credentials & click on login$")
	public void user_enters_login_credentials_click_on_login() throws Throwable {
	  System.out.println("User enters login credentials & click on login");
	  dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys("tirumalashetty.harika@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("anjaneya9$");
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	  
	}

	@Then("^Successful login happens & profile name displayed correctly$")
	public void successful_login_happens_profile_name_displayed_correctly() throws Throwable {
	   System.out.println("Successful login happens & profile name displayed correctly");
	   a_title=dr.getTitle();
	   System.out.println(a_title);
	   if(a_title.equals(e_title) )
	   {
		   testresult="pass";
	   }
	   else
	   {
		   testresult="fail";
	   }
	   System.out.println(" Test result "  + testresult);
	}


}
