package Testng;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import Utilies.ExplicitCode;
import pages.Firstpage;
import pages.InThirdpage;
import pages.SecondPage;
import pages.ThirdPage;

public class BECOGNIZANT extends ExplicitCode {
	Firstpage f;
	SecondPage s;
	ThirdPage t;
	InThirdpage i;
  @BeforeClass
  
  public void f() {
	  launchbrowser("chrome","https://be.cognizant.com/");
  }
  @Test(priority=0)
  public void fp() {
	f= new Firstpage(dr);
	f.Chooseaccount("845179@cognizant.com");
  }
  @Test(priority=1)
  public void fp1() {
	s= new SecondPage(dr);
	s.login("845179", "","344");
	String q=s.Name();
	Assert.assertTrue(q.contains("Tejasai "));
	String w=s.Name1();
	Assert.assertTrue(w.contains("Analyst"));
  }
  //@Test(priority=2)
  public void fp2() {
	t=new ThirdPage(dr);
	t.personalize();
  }
 // @Test(priority=3)
  public void fp3() {
	i= new InThirdpage(dr);
	i.acq();
	String r=i.Digi();
	Assert.assertTrue(r.contains("Digital"));
	String m=i.outreach();
	Assert.assertTrue(m.contains("Outreach"));
  }
  
}
