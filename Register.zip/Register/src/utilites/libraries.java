package utilites;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class libraries
{ 
	static WebDriver driver;
	public libraries(WebDriver driver)
	 {
		 this.driver=driver;
	 }
	

	public WebElement waitForElement(By locator,int timeout)
	{
		try
		{
			WebDriverWait wait=new WebDriverWait(driver,timeout);
			WebElement element =wait.until(
					ExpectedConditions.visibilityOfElementLocated(locator)
					);
			System.out.println("Element located");
			return element;
					
		}
		catch(Exception e)
		{
			System.out.println("Element not located"  + e);
		}
		return null;
	}
	public WebElement elementToBeClickable(By locator,int timeout)
	{
		try
		{
			WebDriverWait wait=new WebDriverWait(driver,timeout);
			WebElement element =wait.until(
					ExpectedConditions.elementToBeClickable(locator)
					);
		                              
		System.out.println("Element located");
		return element;
				
	}
	catch(Exception e)
	{
		System.out.println("Element not located"  + e);
	}
	return null;									
	}
	
	
	
	 
	 public void sst()
	{
		int i=1;
		

	         File f1=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	         File f2=new File("C:\\Users\\BLTuser.BLT0211\\Desktop\\Harika\\screenshots["+i+"].png");
	         try 
	         {
	            FileUtils.copyFile(f1,f2);
	         }
	         catch (IOException e)
	         {
	
	        	 // TODO Auto-generated catch block
	
	        	 e.printStackTrace();
	         }
	         i++;
	}
	 
	}


