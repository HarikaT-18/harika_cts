package tests;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.page_1;
import pages.page_2;
import pages.page_3;
import pages.page_4;
import pages.page_5;

public class chromebrowser 
{
	 static WebDriver dr;
	
	@BeforeClass
	 public void beforeClass()
	 {
	     System.setProperty("webdriver.chrome.driver", "chromedriver_V79.exe");
	     dr=new ChromeDriver();
	     dr.get("https://jpetstore.cfapps.io/catalog");
	     dr.manage().window().maximize();
	 }

	  @Test(priority=0)
	  public void f1()
	  {
	    page_1 p1=new page_1(dr);

	     p1.sin();
	     String aR=dr.getTitle();
	     Assert.assertTrue(aR.contains("JPetStore Demo"));

	  }
	  @Test(priority=1)
	  public void f2()
	  {
	 page_2 p2=new page_2(dr);
	 p2.newregister();
	 String aR=dr.getTitle();
	 Assert.assertTrue(aR.contains("JPetStore Demo"));

	  }
	  @Test(priority=2)
	  public void f3()
	  {
	 page_3 p3=new page_3(dr);
	p3.reginfo("sdgjashgdrt", "12345678901", "12345678901", "latha", "koni","ssdhjasgsjfd@gmail.com", "123456789", "sdhghs", "sydgua", "sydhgj", "sdhj", "12345", "sdhgjh", "Japanese", "BIRDS");
	String aR=dr.getTitle();
	 Assert.assertTrue(aR.contains("JPetStore Demo"));
	 
	  }
	  @Test(priority=3)
	  public void f4()
	  {
	 page_4 p4=new page_4(dr);
	 p4.login("sdgjashgdrt", "12345678901");
	 String aR=dr.getTitle();
	 Assert.assertTrue(aR.contains("JPetStore Demo"));

	  }
	 
	 @Test(priority=4)
	public void f5()
	{
	page_5 p5=new page_5(dr);
	String a=p5.verify_login();
	Assert.assertTrue(a.contains("Sign Out"));

	}
	 
	 @AfterClass
	 public void ac()
	 {
	dr.close();
	 }
	}
  

