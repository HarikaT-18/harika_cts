package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;


public class page_1
{
	 static WebDriver dr;
	libraries d;
	
	public page_1(WebDriver dr)
	{
	  this.dr=dr;
	  d=new libraries(dr);
	
	}
	
	By s=By.xpath("//*[@id='MenuContent']//a[2]");
	public void signin()
	{
	
	WebElement We_s=d.elementToBeClickable(s, 200);
	We_s.click();
	//d.sst();
	
	}
	public void sin()
	{
		this.signin();
	}

}


