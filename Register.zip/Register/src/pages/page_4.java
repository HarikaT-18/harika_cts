package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;

public class page_4 
{
	WebDriver dr;
	libraries d;
	
	public page_4(WebDriver dr)
	{
	this.dr=dr;
	d=new libraries(dr);
	
	}

	By usn=By.xpath("//*[@name='username']");
	By pwd=By.xpath("//*[@name='password']");
	By log=By.xpath("//*[@id='login']");

	public  void user(String u)
	{
	WebElement us=d.waitForElement(usn, 20);
	us.sendKeys(u);
	}
	public  void psd(String p)
	{
	WebElement u=d.waitForElement(pwd, 20);
	u.sendKeys(p);
	}
	public  void log()
	{
	WebElement l=d.waitForElement(log, 20);
	l.click();
	}
	public void login(String u, String p)
	{
	this.user(u);
	this.psd(p);
	d.sst();
	this.log();
	}
	}




