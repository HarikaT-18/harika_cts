package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;

public class page_5 
{
	WebDriver dr;
	libraries d;
	
	public page_5(WebDriver dr)
	{
	this.dr=dr;
	d=new libraries(dr);
	
	}
	By vef=By.xpath("//*[@id='MenuContent']//a[2]");
	public String verify_login()
	{
	d.sst();
	WebElement w=d.waitForElement(vef, 20);
	String a=w.getText();
	return a;
	}
	}


