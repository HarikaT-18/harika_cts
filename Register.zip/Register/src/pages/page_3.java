package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import utilites.libraries;

public class page_3
{
	WebDriver dr;
	libraries d;
	
	public page_3(WebDriver dr)
	{
	this.dr=dr;
	d=new libraries(dr);
	
	}

	By usn=By.xpath("//*[@id='username']");
	By pwd=By.xpath("//*[@id='password']");
	By rpd=By.xpath("//*[@id='repeatedPassword']");
	By fn=By.xpath("//*[@id='firstName']");
	By ln=By.xpath("//*[@id='lastName']");
	By email=By.xpath("//*[@id='email']");
	By phone=By.xpath("//*[@id='phone']");
	By add1=By.xpath("//*[@id='address1']");
	By add2=By.xpath("//*[@id='address2']");
	By city=By.xpath("//*[@id='city']");
	By state=By.xpath("//*[@id='state']");
	By zip=By.xpath("//*[@id='zip']");
	By country=By.xpath("//*[@id='country']");
	By lang=By.xpath("//*[@id='languagePreference']");
	By categ=By.xpath("//*[@id='favouriteCategoryId']");
	By list=By.xpath("//*[@id='listOption1']");
	By banner=By.xpath("//*[@id='bannerOption1']");
	By save=By.xpath("//*[@id='save']");

	public void name(String un)
	{
	WebElement u=d.waitForElement(usn, 20);
	u.sendKeys(un);
	}
	public void pwd(String pd)
	{
	WebElement p=d.waitForElement(pwd, 20);
	p.sendKeys(pd);
	}
	public void rpd(String rpwd)
	{
	WebElement rp=d.waitForElement(rpd, 20);
	rp.sendKeys(rpwd);
	}
	public void fname(String f)
	{
	WebElement fname=d.waitForElement(fn, 20);
	fname.sendKeys(f);
	}
	public void lname(String l)
	{
	WebElement lname=d.waitForElement(ln, 20);
	lname.sendKeys(l);
	}
	public void email(String en)
	{
	WebElement e=d.waitForElement(email, 20);
	e.sendKeys(en);
	}
	public void phone(String ph)
	{
	WebElement p=d.waitForElement(phone, 20);
	p.sendKeys(ph);
	}
	public void add1(String a)
	{
	WebElement a1=d.waitForElement(add1, 20);
	a1.sendKeys(a);
	}
	public void add2(String a)
	{
	WebElement a2=d.waitForElement(add2, 20);
	a2.sendKeys(a);
	}
	public void city(String c)
	{
	WebElement ci=d.waitForElement(city, 20);
	ci.sendKeys(c);
	}
	public void state(String s)
	{
	WebElement st=d.waitForElement(state, 20);
	st.sendKeys(s);
	}
	public void zip(String z)
	{
	WebElement zi=d.waitForElement(zip, 20);
	zi.sendKeys(z);
	}
	public void country(String c)
	{
	WebElement co=d.waitForElement(country, 20);
	co.sendKeys(c);
	}
	public void language(String lan)
	{
	WebElement la=d.waitForElement(lang, 20);
	Select a=new Select(la);
	a.selectByVisibleText(lan);
	}
	public void category(String cat)
	{
	WebElement ca=d.waitForElement(categ, 20);
	Select b=new Select(ca);
	b.selectByVisibleText(cat);
	}
	public void list()
	{
	WebElement li=d.elementToBeClickable(list, 20);
	li.click();
	}
	public void banner()
	{
	WebElement b=d.elementToBeClickable(banner, 20);
	b.click();
	}
	public void save()
	{
	WebElement c=d.elementToBeClickable(save, 20);
	c.click();
	}
	public void reginfo(String un,String pd,String rpwd,String f,String l,String en, String ph, String a1,String a2,String ci,String s, String z, String co, String lan, String cat)
	{
	this.name(un);
	this.pwd(pd);
	this.rpd(rpwd);
	this.fname(f);
	this.lname(l);
	this.email(en);
	this.phone(ph);
	this.add1(a1);
	this.add2(a2);
	this.city(ci);
	this.state(s);
	this.zip(z);
	this.country(co);
	this.language(lan);
	this.category(cat);
	this.list();
	this.banner();
	d.sst();
	this.save();

	}

	}



