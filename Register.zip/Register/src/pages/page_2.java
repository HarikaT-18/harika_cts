package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;

public class page_2 
{
	WebDriver dr;
	libraries d;
	
	public page_2(WebDriver dr)
	{
	this.dr=dr;
	d=new libraries(dr);
	
	}
	;
	By reg=By.xpath("//*[@id='Catalog']//a");
	public void newregister()
	{
	d.sst();
	WebElement r=d.elementToBeClickable(reg, 20);
	r.click();
	}
	}


