package automation_testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class page1 
{
	static WebDriver dr;

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		dr=new ChromeDriver();
		dr.get("http://practice.automationtesting.in/");
		dr.findElement(By.xpath("//ul[@id='main-nav']//li[2]//a")).click();
//		dr.findElement(By.xpath("//form[@class='register']//input[1][@type='email']")).sendKeys("tirumalasettyharika97@gmail.com");
//		dr.findElement(By.xpath("//form[@class='register']//input[@type='password']")).sendKeys("Anjaneya123R9$");
//		dr.findElement(By.xpath("//form[@class='register']//input[@type='submit']"));
//		WebDriverWait w =new WebDriverWait(dr,70);
//		WebElement e=w.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[@class='register']//input[@type='submit']")));
//		e.click();
//		
//		//login//
//		dr.findElement(By.xpath("//form[@class='login']//input[@name='username']")).sendKeys("tirumalasettyharika97@gmail.com");
//		dr.findElement(By.xpath("//form[@class='login']//input[@name='password']")).sendKeys("Anjaneya123R9$");
//		dr.findElement(By.xpath("//form[@class='login']//input[@type='submit']"));
//		
//		WebDriverWait w1 =new WebDriverWait(dr,70);
//		WebElement e1=w1.until(ExpectedConditions.elementToBeClickable(By.xpath("//form[@class='login']//input[@type='submit']")));
//		e1.click();
		
		//shop the product
		dr.findElement(By.xpath("//ul[@id='main-nav']//li[1]//a")).click();
		dr.findElement(By.xpath("//ul[@class='product-categories']//li[4]//a"));
		

		WebDriverWait w2 =new WebDriverWait(dr,70);
		WebElement e2=w2.until(ExpectedConditions.elementToBeClickable(By.xpath("//ul[@class='product-categories']//li[4]//a")));
		e2.click();
		
		dr.findElement(By.xpath("//a[@rel='nofollow']")).click();
		
		dr.findElement(By.xpath("//ul[@id='main-nav']//li[5]//a")).click();
		
		//register in demo site
		
		dr.findElement(By.xpath("//input[@placeholder='First Name']")).sendKeys("T");
		dr.findElement(By.xpath("//input[@placeholder='Last Name']")).sendKeys("H");
		dr.findElement(By.xpath("//textarea[@ng-model='Adress']")).sendKeys("skdnagar");
		dr.findElement(By.xpath("//input[@ng-model='EmailAdress']")).sendKeys("tirumalashetty.harika@gmail.com");
		dr.findElement(By.xpath("//input[@ng-model='Phone']")).sendKeys("9675345190");
		dr.findElement(By.xpath("//input[@value='FeMale']")).click();
		dr.findElement(By.xpath("//input[@id='checkbox1']")).click();
		
//		
//		WebElement we=dr.findElement(By.xpath("//div[@class='ui-autocomplete-multiselect ui-state-default ui-widget']"));
//		Select s=new Select(we);
//		s.selectByVisibleText("English");
		
		dr.findElement(By.xpath("//div[@class='ui-autocomplete-multiselect ui-state-default ui-widget']")).click();
		
		
		dr.findElement(By.xpath("//ul[@class='ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all']//li[8]//a")).click();
		WebElement we1=dr.findElement(By.xpath("//select[@id='Skills']"));
		Select s1=new Select(we1);
		s1.selectByVisibleText("C");
		
		WebElement we2=dr.findElement(By.xpath("//select[@id='countries']"));
		Select s2=new Select(we2);
		s2.selectByVisibleText("India");
//		
//		WebElement we3=dr.findElement(By.xpath("//span[@class='select2-selection select2-selection--single']"));
//		Select s3=new Select(we3);
//		s3.selectByVisibleText("India");
		
		dr.findElement(By.xpath("//span[@class='select2-selection__arrow']")).click();
		
		dr.findElement(By.xpath("//*[@id=\"select2-country-results\"]/li[6]")).click();
		
		
		
		
//
//		WebElement we4=dr.findElement(By.xpath("//select[@placeholder='Year']"));
//		Select s4=new Select(we2);
//		//s4.selectByVisibleText("2015");
//		s4.selectByIndex(2015);
		
		dr.findElement(By.xpath("//select[@id='yearbox']//option[10]")).click();//select[@id='yearbox']//option[10]
		
		dr.findElement(By.xpath("//select[@placeholder='Month']//option[4]")).click();
		
		dr.findElement(By.xpath("//select[@placeholder='Day']//option[4]")).click();
//		
//		WebElement we5=dr.findElement(By.xpath("//select[@placeholder='Month']"));
//		Select s5=new Select(we2);
//		s5.selectByVisibleText("March");
//		
//
//		WebElement we6=dr.findElement(By.xpath("//select[@placeholder='Day']"));
//		Select s6=new Select(we2);
//		s6.selectByVisibleText("19");
		
		dr.findElement(By.xpath("//input[@id='firstpassword']")).sendKeys("Jasdgh910");
		dr.findElement(By.xpath("//input[@id='secondpassword']")).sendKeys("Jasdgh910");
		
		WebDriverWait w7 =new WebDriverWait(dr,70);
		WebElement e6=w7.until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='submitbtn']")));
		e6.click();
		

	}

}
