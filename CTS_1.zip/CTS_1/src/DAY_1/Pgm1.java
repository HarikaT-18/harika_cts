package DAY_1;

public class Pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//System.out.println("hello world");
		int a=10,b=20;
		System.out.println(a>b);
		System.out.println(a==10);
	}

}
