package DAY_1;
import java.util.Scanner;

public class Pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,c;
		Scanner s=new Scanner(System.in);
		System.out.println("Enter values");
		a=s.nextInt();
		b=s.nextInt();
		c=s.nextInt();
		if(a<b)
		{
		 if(a<c)
		 
			 System.out.println(a + " smallest number");
			 
			 else
				 
				 System.out.println(c + " is the smallest number");
		 }
		
	else if(b<c)
	{
		
		System.out.println(b + " is the smallest number");
	}
	else
	
		
		System.out.println(c + " is the smallest number");
	

		}
	

}
