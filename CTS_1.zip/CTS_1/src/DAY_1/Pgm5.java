package DAY_1;

public class Pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=30,b=70,c=50;
		if(a<b && a<c)
			System.out.println(a + " is the smallest number");
		else if(b<a && b<c)
			System.out.println(b + "is the smallest number");
		else
			System.out.println(c + " is the smallest number");

	}

}
