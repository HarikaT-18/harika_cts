package DAY_1;
import java.util.Scanner;

public class Pgm18 {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("Enter the number : ");
		int num = s.nextInt();
		boolean prime=true;
		int x=2;
		while(x<=num/2)
		{
		int r =num % x;
		if(r==0)
		{
		prime = false;
		break;
		}

		}
		if(prime==true)
		{
			System.out.println(" entered number is prime " );
		}
		else
		{
		System.out.println(" enetered number is not prime");
		}
		}

		
		


	}


