package DAY_1;

public class Pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,c=0;
		for(i=1;i<=50;i++)
		{
		if((i%3==0) && (i%5!=0))
		{
			System.out.println(i);
			c++;
		}

		}
	}

}
