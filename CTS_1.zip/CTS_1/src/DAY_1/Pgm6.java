package DAY_1;

public class Pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		long salary=7500000 ;
		 long s1 = 0;
		float t;
		
		if(salary<180000)
		{
			System.out.println(" interest is 0");
		}
		else if(salary>180001 && salary<=500000)
		{
			s1=salary-180000;
			t=s1*0.1f;
		}
		else if(salary>500000 && salary<=800000)
		{
			s1= salary-500000;
			t=s1*0.2f ;
			salary=s1;
			s1=salary-180000;
			t+=s1*0.1f;
			System.out.println("tax to be paid :" +t);
			
		}
		
			

	}

}
