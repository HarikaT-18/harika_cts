package DAY_1;
import java.util.Scanner;

public class Pgm16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num,m, count = 0, count1,a,key;

		int arr1[] = {0,0,0,0,0,0,0,0,0,0};

		Scanner sc;

		sc = new Scanner(System.in);
		System.out.println("\n Enter interger : ");
		num = sc.nextInt();

		m = num;

		while(num> 0)
		{
			num = num /10;
			count = count + 1;

		}

		count1 = count;

		
		while(m > 0)
		{
			a = m % 10;

			m = m/10;

			count = count - 1;
			arr1[count] = a;

			System.out.println(a);

		}

		for(int i =0;i<count1;i++)
		{

			key = arr1[i];

			switch(key)

			{
				case 0: System.out.print("Zero ");
					break;


				case 1: System.out.print("One ");
					break;
				case 2: System.out.print("two ");
					break;
				case 3: System.out.print("three ");
					break;
				case 4: System.out.print("four ");
					break;
				case 5: System.out.print("five ");
					break;
				case 6: System.out.print("six ");
					break;
				case 7: System.out.print("seven ");
					break;
				case 8: System.out.print("eight ");
					break;
				case 9: System.out.print("nine ");
					break;
				default: System.out.print("Invalid num ");
					break;
				

			}





	}

	}
}
