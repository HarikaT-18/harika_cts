package Day_5;

public class rectangle implements Example
{
public void draw()
{
	System.out.println("Draw rectangle");
}
}
