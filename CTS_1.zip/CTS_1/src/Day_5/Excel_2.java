package Day_5;

public class Excel_2 {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		getexcel e1=new getexcel();
		 String s=e1.readdata("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\ha.xlsx","Sheet1",0,0);
		 System.out.println(s);
		 e1.writedata("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\ha.xlsx","Sheet2",0,0,"I am harika");
		

	}

}
