package Day_5;

public class Student{
	int id;
	String name;
	int selenium,java;
	float avg;
	public Student(String name,int id,int java,int selenium)
	{
		
		
		this.name=name;this.id=id;
		this.java=java;this.selenium=selenium;
	}
	public void calc_avg()
	{
		avg=(selenium+java)/2.0f;
	}
}


