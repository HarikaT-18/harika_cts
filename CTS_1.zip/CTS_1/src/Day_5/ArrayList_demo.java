package Day_5;
import java.util.ArrayList;

public class ArrayList_demo
{
    ArrayList<Student> std_al=new ArrayList<Student>();
    
    public void create_al()
    {
    	Student s1=new Student ("ramesh",101,86,90);
    	Student  s2=new Student("anil",102,89,90);
    	std_al.add(s1);
    	std_al.add(s2);
    }
     
    public void display_al()
    {
    	
    	for(Student s:std_al)
    	{
    		System.out.println(" Name : " +s.name
    		                  + " Id : "    +s.id
    		                   +" java : "  +s.java
    		                   +" selenium marks : "  +s.selenium);
    	} 	 	 
	
    }
    public static void main(String[] args)
	{
		ArrayList_demo a=new ArrayList_demo();
		a.create_al();
		a.display_al();
	}

}
