package Day_5;

public interface Example
{
     void draw();
}
