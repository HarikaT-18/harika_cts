package Day_5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class getexcel 
{
	

	public String readdata(String finame,String sname,int r,int c) 
	{
		// TODO Auto-generated method stub
		 String s=null;    
        
         try
         {
        	 File f=new File(finame);
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(sname);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.getCell(c);
			 s=cell.getStringCellValue();
			//System.out.println(s);							
				
		} 
         catch (FileNotFoundException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         catch (IOException e)
         {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         return s;
	}
         public void writedata(String finame,String sname,int r,int c,String data)
         {
        	  try
              {
             	 File f=new File(finame);
     			FileInputStream fis=new FileInputStream(f);
     			XSSFWorkbook wb=new XSSFWorkbook(fis);
     			XSSFSheet sh=wb.getSheet(sname);
     			XSSFRow row=sh.getRow(r);
     			XSSFCell cell=row.getCell(c);
     			 cell.setCellValue(data);
     			 FileOutputStream fos=new FileOutputStream(f);
     			 wb.write(fos);
              } 
        	  catch (FileNotFoundException e) 
      		{
      			// TODO Auto-generated catch block
      			e.printStackTrace();
      		}
               catch (IOException e)
               {
      			// TODO Auto-generated catch block
      			e.printStackTrace();
      		}
         }
}

