package Day_5;
import java.util.ArrayList;

public class Arraylist_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<String> str_al=new ArrayList<String>();
		
		str_al.add("harika");
		str_al.add("hari");
		str_al.add("joshi");
		str_al.add("lavanya");
		str_al.add("1");
		
		System.out.println("Before insertion : " +str_al);
		
		 str_al.add(2,"priya");
		 System.out.println("After insertion :" +str_al);
		 
		 str_al.remove("hari");
		 System.out.println("After deletion : " +str_al);
		 
		 str_al.remove(1);
		 System.out.println("After deletion : " +str_al);
		 
		 str_al.add(3,"kumar");
		 System.out.println("After insertion : " +str_al);
		 
		 for(String s:str_al)
		 {
			 System.out.println(s);
		 }
		 

	}

}
