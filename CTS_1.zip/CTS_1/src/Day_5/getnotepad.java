package Day_5;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.imageio.IIOException;

public class getnotepad {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		try
		{
			FileInputStream fin=new FileInputStream("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\notepad.txt");
			int i;
			//i=fin.read();
		
		while((i=fin.read())!=-1)
		{
			System.out.print((char)i);
			
		}
		
			fin.close();
			FileOutputStream fos=new FileOutputStream("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\notepad.txt");
			byte[] d=" I am harika".getBytes();
			fos.write(d);
			fos.close();
			
	    }          
		catch(IOException e)
		{
			e.printStackTrace();
		}

	
		
			
		
}

	
	
}

