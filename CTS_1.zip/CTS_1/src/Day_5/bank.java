package Day_5;

public abstract class bank
{
   abstract float get_roi();

    public void show()
{
	System.out.println(" Bank Details");
}
}
