package Day_5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class read_excel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String[] str={"hello","india","how","are","you"};
	

        try
        {
        	
        	File f=new File("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\ri.xlsx");
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet("Sheet1");
			XSSFRow row=sh.getRow(0);
			XSSFCell cell=row.getCell(0);
			String s=cell.getStringCellValue();
			System.out.println(s);
			XSSFSheet sh1=wb.getSheet("Sheet2");
			XSSFRow r=sh1.getRow(0);
			XSSFCell c=r.getCell(0);
			
			
			c.setCellValue(s);
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
		
	

        } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
      /*  try
        {
        	
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh1=wb.getSheet("Sheet2");
			XSSFRow r=sh1.getRow(0);
			XSSFCell c=r.getCell(0);
			
			
			c.setCellValue("pune");
			FileOutputStream fos=new FileOutputStream(f);
			wb.write(fos);
        } catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	*/

}
}
