package DAY_2;

public class Pgm12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str= "Hello,how are you ?";
		char c='o';
		int i,fact=0;
		for(i=0;i<str.length();i++)
		{
			if(str.charAt(i)==c)
				fact++;
		}
		
System.out.println(fact);
	}

}
