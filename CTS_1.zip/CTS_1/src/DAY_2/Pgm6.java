package DAY_2;

public class Pgm6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				String sub=" I am learning java",s1;
				int i=0,c=0,p1=0,p;
				
				
				while(p1!=-1)
				{
					p1=sub.indexOf(" ",i);
					c++;
					if(p1==-1) 
					{
						p=sub.length();
						p1=p;
					}
					
					s1=sub.substring(i,p1);
					i=p1+1;
					System.out.println(s1);
					System.out.println("i ="+i + "p1="+p1);
					
					
				}
				

	}

}
