package DAY_2;

public class Pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] marks={90,82,92,90,83,87,89};
		int sum=0,i;
		float avg;
		for(i=0;i<=6;i++)
		{
			sum=sum+marks[i];
		}
		avg=sum/7;
		System.out.println(avg);
		if(avg>=70)
		{
			System.out.println("First class with distinction");
			
		}
		else if(avg>=60 && avg<70)
		{
			System.out.println("First Class");
		}
		else
		System.out.println(" second Class");
		
	}

}
