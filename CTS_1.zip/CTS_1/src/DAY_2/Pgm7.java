package DAY_2;

public class Pgm7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=2,c;
		int m[]={2,4,6};
		try
		{
		c=a/b;
		System.out.println("after");
		System.out.println(c);
		}
	catch(Exception e)
	{
		
			System.out.println("in catch blk");
	}
	
		System.out.println(m[4]);

	}

}
