package DAY_2;

public class Pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] marks={91,82,92,90,83,87,89};
		int sum=0,i;
		for(i=0;i<7;i=i+2)
		{
			if(marks[i]%2==1)
			{
				sum=sum+marks[i];
			}
			
		}
System.out.println(sum);
	}

}
