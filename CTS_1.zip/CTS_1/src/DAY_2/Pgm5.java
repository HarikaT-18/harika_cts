package DAY_2;

public class Pgm5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s=" I am harika";
		int i=0,c=0,p=0;
		while(p!=-1)
		{
			p=s.indexOf(" ",i);
			c++;
			i=p+1;
			
		}
System.out.println(c);
	}

}
