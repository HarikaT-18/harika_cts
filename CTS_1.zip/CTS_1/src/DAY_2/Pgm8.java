package DAY_2;

public class Pgm8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10,b=2,c;
int m[]={2,3,4};
try
{
	c=a/b;
	System.out.println(m[4]);
}
catch(ArithmeticException e)
{
	System.out.println(" Arithmetic exception");
}
catch(ArrayIndexOutOfBoundsException el)
{
	System.out.println(" out of bounds exception");
}
	}

}
