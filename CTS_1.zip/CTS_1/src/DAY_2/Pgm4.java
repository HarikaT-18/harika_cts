package DAY_2;

public class Pgm4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Bangalore",s2="bangalore",s3="banglore",s4;
		int l =s1.length();
		int v=s1.compareTo(s2);
		System.out.println("length =" +l+ " return value : " +v);
		int rv=s1.compareToIgnoreCase(s2);
		System.out.println(" rv =" +rv);
		s4=s1.substring(0,3);
		System.out.println("Substring :" +s4);
		
		

	}

}
