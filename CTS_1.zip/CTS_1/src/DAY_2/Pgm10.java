package DAY_2;

public class Pgm10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int [] a={-2,4,18};
		int r,c,la,i;
		int max = a[0];
		for(i=1;i<a.length;i++)
		{
	if(a[i]>max)
	{
		max=a[i];
	}
		}
		System.out.println(max);
				

	}

}
