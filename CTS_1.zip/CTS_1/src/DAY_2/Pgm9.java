package DAY_2;

public class Pgm9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[][]={{18,4,-2,29},{8,99,23,18}};
		int i=3,j;
		int []result=new int[i];
		int max = a[0][0];
		i=0;
		while(i<a.length)
		{
			for(j=0;j<=a.length;j++)
			{
				if(a[i][j]>max)
				max=a[i][j];	
			}
		}
			result[i]=max;
			max=0;
			i++;
			for(i=0;i<result[i]; i++)
			System.out.println(max);
		
	
		
				

	}

}
