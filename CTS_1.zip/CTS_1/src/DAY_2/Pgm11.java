package DAY_2;

public class Pgm11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i,j,sum;
int a[]={21,34,91,59,16,44,29,74,49,82};
for(i=0;i<10;i++)
{
	for(j=i+1;j<10;j++)
	{
		sum=a[i]+a[j];
		if(sum==65)
		{
			System.out.println(a[i]+a[j]);
		}
	}
}
	}

}
