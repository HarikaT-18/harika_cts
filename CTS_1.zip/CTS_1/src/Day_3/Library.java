package Day_3;

public class Library {

	public int add(int x,int y)
	{
		int z;
		z=x+y;
		return z;
	}
	public int power(int x,int y)
{
		int power=1;
		for(int i=1;i<=y;i++)
		{
			power=power*x;
		}
		return power;
	
}
}
