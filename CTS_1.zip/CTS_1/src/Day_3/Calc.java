package Day_3;

public class Calc extends Library {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Calc c=new Calc();
		int d=c.add(3,5);
		System.out.println("Addition : " + d);
		
		int a=c.power(2, 5);
		System.out.println("Power: " + a);
		

	}                                                 

}
