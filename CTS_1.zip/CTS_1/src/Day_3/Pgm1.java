package Day_3;
import java. util.Scanner;

public class Pgm1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int count=0;
		System.out.println("enter a character:");
		Scanner s=new Scanner(System.in);
		char c=s.next().charAt(0);
		while(c!='n')
		{
			
			if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
			{
				count++;
			}
			c=s.next().charAt(0);
			
			
		}
		
		System.out.println(count);
	}

}
