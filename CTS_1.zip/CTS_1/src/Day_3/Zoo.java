package Day_3;

public class Zoo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Elephant e1=new Elephant();
		e1.age=5;
		e1.weight=50;
		e1.height=3;
		e1.lotrunk=1;
		e1.lotusk=2;
		e1.gender='f';
		e1.display_details();
		
		


	}

}
