package Day_3;

import java.util.Scanner;

public class Pgm3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String or,re=null;
		System.out.println("Enter a string:");
		Scanner s =new Scanner(System.in);
	 or=s.nextLine();
	 int length=or.length();
	for(int i=length-1;i>=0;i--)
	{
		re=re+or.charAt(i);
		
	
	}
	if(or==re)
	
		System.out.println("Entered string is palindrome");
	 else
		 System.out.println("entered sting is not a palindrome");
	}
	
}
