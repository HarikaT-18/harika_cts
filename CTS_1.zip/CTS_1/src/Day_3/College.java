package Day_3;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i;
		float f;
		Student ramesh=new Student();
		ramesh.java=80;
		ramesh.selenium=90;
		ramesh.calc_avg();
		System.out.println("Average marks of ramesh = " +ramesh.avg);
	}

}
