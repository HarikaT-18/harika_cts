package Day_3;

public class bascal
{
	int num1=10,num2=8,num;
	public void add() {
		
		num=num1+num2;
		System.out.println("add fun "+num);
	}
   public void sub() {
		
		num=num1-num2;
		System.out.println("sub fun  " +num);
	}

}
