package Day_3;

public class Animal {
	int age,weight,height;
	char gender;
	
	public void display()
	{
		System.out.println("height = " +height +" weight = " +weight + "Age = " +age);
	}

}
