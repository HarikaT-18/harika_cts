package Day_3;

	public class Derivedcal extends bascal {
		public void mul()
		{
			
			num=num1*num2;
			System.out.println(num);
		}
		}

