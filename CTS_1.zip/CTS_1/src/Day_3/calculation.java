package Day_3;

public class calculation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derivedcal d=new Derivedcal();
		d.mul();
		d.add();
		d.sub();

	}

}
