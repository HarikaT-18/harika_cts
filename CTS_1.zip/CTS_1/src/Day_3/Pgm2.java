package Day_3;
import java.util.Scanner;

public class Pgm2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i,k=1;
		String[][] ename={{"e1","harika"},{"e2","rinky"},{"e3","hari"},{"e4","pujitha"},{"e5","swathi"}};
		
		System.out.println("Enter employee id");
		Scanner s =new Scanner(System.in);
		String emp_id=s.nextLine();
		for(i=0;i<4;i++)
			
		{
	
			     int j=0;
				k=emp_id.compareTo(ename[i][j]);
				if(k==0)
					System.out.println(ename[i][j+1]);
			
				
			}
		
		
		
		

	}

}
