package Day_4;

public class Employee_search
{
     int z;
 
	static String[][] emp={{"11","ramesh"},{"12","satish"},{"13","priya"}};
	static int[][] marks={{11,65,67,0},{12,75,85,0},{13,67,89,0}};
	
	public static int search (String sid)
	{
		int index=0,i;
		int id=Integer.parseInt(sid);
		for(i=0;i<=4;i++)
		{
			if(id==marks[i][0])
			{
				index=i;
				break;
			}
		}
		return index;
	}
	
	public static int calc_avg(int ind)
	{
		int avg;
		avg=(marks[ind][1]+marks[ind][2])/2;
		return avg;
	}
	
	public static String get_name(String stdid)
	{
		String n=null;
		for(int j=0;j<=4;j++)
		{
			if(stdid.equals(emp[j][0]))
			{
				n=emp[j][1];
				break;
			}
		}
		return n;
	}
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		int i=search("13");
		int average=calc_avg(i);
		String name=get_name("13");
		System.out.println("Name : " +name + " Average : " +average);

		

	
	}

}
