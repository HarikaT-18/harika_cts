package Day_4;

public class Polymor_ex {

	public int add(int x,int y)
	{
		int z=x+y;
		System.out.println(" two parameters");
		return z;
		
	}
	
	public int add(int a,int b,int c)
	{
		int d=a+b+c;
		System.out.println(" three parameters");
		return d;
	}
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Polymor_ex calc=new Polymor_ex();
		int m=calc.add(8,10);
		System.out.println(m);
		int m1=calc.add(20,45,67);
		System.out.println(m1);
		

	}

}
