package Day_4;

public class College {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i;
		float f;
		
		Student ramesh=new Student(80,90);
		ramesh.calc_avg();
		System.out.println("Average marks of ramesh = " +ramesh.avg);
		
		Student hema=new Student(67,45);
		hema.calc_avg();
		System.out.println("Average marks of hema = " +hema.avg);
	}

}
