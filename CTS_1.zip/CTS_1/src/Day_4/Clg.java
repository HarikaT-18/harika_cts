package Day_4;

    public class Clg {
	int z;
	static String[][] emp={{"11","ramesh"},{"12","satish"},{"13","priya"}};
	static int[][] m={{11,65,67,0},{12,75,85,0},{13,67,89,0}};
	
	
	public int calc_avg(int i,int j)
	{
		z=(i+j)/2;
		return z;
	}
	
	public int search(String s)
	{
		int i=Integer.parseInt(s);
		return i;
	}
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		
		int x,j,index;
		Clg a=new Clg();
		System.out.println( "Id " +" Name " + " Average");
		
          for(x=0;x<emp.length;x++)
		{
	         index=a.search(emp[x][0]);
	         
	             if(index==m[x][0])
	             {
	            	 j=a.calc_avg(m[x][1], m[x][2]);
			   
			    System.out.println(emp[x][0] + " " +emp[x][1]+ " " +j);
				     
				    				
			       }
	       }

}
}

