package utilites;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class libraries
{ 
	WebDriver driver;
	Logger log;
	public libraries(WebDriver driver)
	 {
		 this.driver=driver;
		 log=Logger.getLogger("devpinoyLogger");
	 }
	public void update_log(String msg)
	{
		log.debug(msg);
	}
	

	public WebElement waitForElement(By locator,int timeout)
	{
		try
		{
			WebDriverWait wait=new WebDriverWait(driver,timeout);
			WebElement element =wait.until(
					ExpectedConditions.visibilityOfElementLocated(locator)
					);
			System.out.println("Element located");
			return element;
					
		}
		catch(Exception e)
		{
			System.out.println("Element not located"  + e);
		}
		return null;
	}
	public WebElement elementToBeClickable(By locator,int timeout)
	{
		try
		{
			WebDriverWait wait=new WebDriverWait(driver,timeout);
			WebElement element =wait.until(
					ExpectedConditions.elementToBeClickable(locator)
					);
		                              
		System.out.println("Element located");
		return element;
				
	}
	catch(Exception e)
	{
		System.out.println("Element not located"  + e);
	}
	return null;									
	}
	public class ss
	{
	WebDriver dr;
	public ss(WebDriver dr)
	{
	this.dr=dr;
	}
	 int i=1;
	public void get_screenshot()
	{

	File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
	         File f2=new File("\"C:\\\\Users\\\\BLTuser.BLT0211\\\\Desktop\\\\Harika["+i+"].png");
	         try {
	FileUtils.copyFile(f1,f2);
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	         i++;
	}
	}
	

}
