package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;

public class page_1 
{
	
	WebDriver dr;
	libraries d;
	//ss sr;
	public page_1(WebDriver dr)
	{
	this.dr=dr;
	d=new libraries(dr);
	//sr=new ss(dr);
	}

	

	By usn=By.xpath("//*[@name='username']");
	By pwd=By.xpath("//*[@name='password']");
	By log=By.xpath("//*[@id='login']");

	public  void user(String u)
	{
	//WebElement us=d.waitForElement(usn, 20);
	//us.sendKeys(u);
		dr.findElement(usn).sendKeys(u);
	}
	public  void psd(String p)
	{
	//WebElement u=d.waitForElement(pwd, 20);
	//u.sendKeys(p);
		dr.findElement(pwd).sendKeys(p);
	}
	public  void log()
	{
	//WebElement l=d.waitForElement(log, 20);
	//l.click();
		dr.findElement(log).click();
	}
	public void login(String e, String f)
	{
	this.user(e);
	this.psd(f);
	//sr.sst();
	this.log();
	}
	}


