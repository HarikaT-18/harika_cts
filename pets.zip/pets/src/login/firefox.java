package login;


import java.io.File;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class firefox extends excel_data
{
	 static WebDriver dr;
	//petslogin e2=new petslogin(dr);
	
  @Test(dataProvider="register")
  public void f(String uid,String pwd,String s2) 
  {
	  System.setProperty("webdriver.gecko.driver","Firefox Installer.exe");
	  File pathBinary = new File("C:\\Users\\BLTuser.BLT0211\\AppData\\Local\\Mozilla Firefox\\firefox.exe");
	  FirefoxBinary firefoxBinary = new FirefoxBinary(pathBinary);   
	  DesiredCapabilities desired = DesiredCapabilities.firefox();
	  FirefoxOptions options = new FirefoxOptions();
	  desired.setCapability(FirefoxOptions.FIREFOX_OPTIONS, options.setBinary(firefoxBinary));
		dr=new FirefoxDriver();
		//dr.get("https://www.google.co.in");
		System.out.println("Webdriver");
		dr.get("https://jpetstore.cfapps.io/login");
		dr.manage().window().maximize();
		System.out.println("user name " +uid  + " password " +pwd);
		petslogin l=new petslogin(dr);
		l.login(uid,pwd);
		String s1=l.verify();
		System.out.println(s1);
		Assert.assertEquals(s1,s2);
	    dr.close();
	 
  }
  @DataProvider(name="register")
  public String[][] register()
  {
  	return testdata;
  }
  @BeforeClass
  public void beforeclass()
  {

	    getexcel();
  }
}
