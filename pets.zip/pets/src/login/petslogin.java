package login;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;

public class petslogin
{
	 	
	 	 WebDriver dr;
	 	libraries d;
	 	//ss sr;
	 	public petslogin(WebDriver dr)
	 	{
	 	this.dr=dr;
	 	d=new libraries(dr);
	 	//sr=new ss(dr);
	 	}

	 	

	 	By usn=By.xpath("/html/body/div[2]/section/div/form/p[2]/input[1]");
	 	By pwd=By.xpath("//input[@name='password']");
	 	By log=By.xpath("//input[@id='login']");
	 	By wel=By.xpath("//div[@id='WelcomeContent']");
	 	public String verify()
	 	{
	 		String s=dr.findElement(wel).getText();
	 		return s;
	 	}
	 	

	 	public  void user(String u)
	 	{
	 		System.out.println(u);
	 	WebElement We_us=d.waitForElement(usn, 20);
	 	We_us.sendKeys(u);
	 
	 		//dr.findElement(usn).sendKeys(u);
	 	}
	 	public  void psd(String p)
	 	{
	 	WebElement We_u=d.waitForElement(pwd, 20);
	 	We_u.sendKeys(p);
	 		//dr.findElement(pwd).sendKeys(p);
	 	}
	 	public  void log()
	 	{
	 	WebElement We_l=d.waitForElement(log, 20);
	 	We_l.click();
	 		//dr.findElement(log).click();
	 	}
	 	public void login(String e, String f)
	 	{
	 	this.user(e);
	 	this.psd(f);
	 	//sr.sst();
	 	this.log();
	 	}
	 	}





