package login;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import utilites.libraries;

public class NewTest extends excel_data
{
	 static WebDriver dr;
	 libraries lib;
	//petslogin l=new petslogin(dr);
	
	 @BeforeClass
	  public void beforeclass()
	 {
	    getexcel();
	    lib=new libraries(dr);
	    lib.update_log("Completed reading from excel");
	  }

@Test(dataProvider="register")	
public void test_login(String uid,String pwd,String s2 )
{
	
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	dr=new ChromeDriver();
	System.out.println("Webdriver");
	dr.get("https://jpetstore.cfapps.io/login");
	dr.manage().window().maximize();
	System.out.println("user name " +uid  + " password " +pwd);
	petslogin l=new petslogin(dr);
	l.login(uid,pwd);
	String s1=l.verify();
	System.out.println(s1);
	Assert.assertEquals(s1,s2);
	lib.update_log("login successful with user name : "+uid + " and password : " + pwd );
    dr.close();
	
}
@Test(priority=1)
public void f()
{
	System.out.println(testdata[0][0]);
	System.out.println(testdata[0][1]); 
}
@DataProvider(name="register")
public String[][] register()
{
	return testdata;
}
	 
}
