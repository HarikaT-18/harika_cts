package login;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utilites.libraries;

public class excel_data 
{
	static String[][] testdata =new String[2][3];
	WebDriver dr;
	int count =0;


	 public static void getexcel()
	{

	try
	{
	File f =new File("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\pets.xlsx");
	FileInputStream fis =new FileInputStream(f);
	XSSFWorkbook wb=new XSSFWorkbook(fis);
	XSSFSheet sh=wb.getSheet("Sheet1");
	for(int r=0;r<=1;r++)
	{

	for(int c=0;c<=2;c++)
	{
	XSSFRow R=sh.getRow(r);
	XSSFCell C=R.getCell(c);
	testdata[r][c] =C.getStringCellValue();
	//System.out.println(testdata);
	}
	}


	} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	}
	
	 
	

}
