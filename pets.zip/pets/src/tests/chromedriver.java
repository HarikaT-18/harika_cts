package tests;

import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.page_1;

public class chromedriver
{
	
	WebDriver dr;

	@BeforeClass
	 public void beforeClass()
	 {
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  dr=new ChromeDriver();
	  dr.get("https://jpetstore.cfapps.io/catalog");
	  dr.manage().window().maximize();
	 }
	  @Test(priority=3)
	  public void f1()
	  {
	 page_1 p1=new page_1(dr);
	 p1.login("sdgjashgd", "123456789");
	 String aR=dr.getTitle();
	 Assert.assertTrue(aR.contains("JPetStore Demo"));

	  }
	
}
