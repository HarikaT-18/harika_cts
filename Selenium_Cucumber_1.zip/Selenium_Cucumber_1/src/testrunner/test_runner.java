package testrunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features="feature",glue="Step_Def")

public class test_runner extends AbstractTestNGCucumberTests  {

}
