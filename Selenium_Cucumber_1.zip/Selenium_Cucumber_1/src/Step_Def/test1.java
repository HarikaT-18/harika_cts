package Step_Def;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class test1 
{
	WebDriver dr;
	String exp_title="Online Bookstore";
	String act_title;
	String act_name="//a[@href='ProductDetail.php?product_id=3']";
	String exp_name="Perl and CGI for the World Wide Web";
	
	@Given("^Browser is launched$")
	public void browser_is_launched() throws Throwable {
	    System.out.println("Browser is launched");
	    System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		  dr=new ChromeDriver();
		  dr.get("http://examples.codecharge.com/Store/Default.php");
	}

	@When("^Select programming from drop down and click search$")
	public void select_programming_from_drop_down_and_click_search() throws Throwable
	{
		act_title=dr.getTitle();
		   System.out.println(act_title);
	 System.out.println("Select programming from drop down and click search");
	 dr.findElement(By.xpath("//select[@name='category_id']//following::option[2]")).click();
	 dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
	 
	}

	@Then("^Verify title & name of the second book$")
	public void verify_title_name_of_the_second_book() throws Throwable {
	   System.out.println("Verify title & name of the second book");
	   
	   act_name=dr.findElement(By.xpath(act_name)).getText();
	   System.out.println(act_name);
	   if(act_title.equals(exp_title) && act_name.equals(exp_name))
	   {
		   System.out.println("Pass");
	   }
	   else
	   {
		   System.out.println("Fail");
	   }
	}


}
