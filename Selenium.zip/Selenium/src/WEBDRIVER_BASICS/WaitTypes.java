package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WaitTypes 
{
	private WebDriver dr1;

	public WaitTypes(WebDriver dr1)
	{
		this.dr1=dr1;
	}
	public WebElement waitforElement(By locator,int timeout)
	{
		try
		
		{
			WebDriverWait wait =new WebDriverWait(dr1,timeout);
			WebElement element =wait.until(
					ExpectedConditions.visibilityOfElementLocated(locator)
					);
			System.out.println("element located");
			return element;
			
		}
		catch(Exception e)
		{
			System.out.println("Element not located");
			
		}
		return null;
	}


public WebElement elementToBeClickable(By locator,int timeout)
{
	try
	{
		WebDriverWait wait =new WebDriverWait(dr1,timeout);
		
		WebElement element =wait.until(
				ExpectedConditions.visibilityOfElementLocated(locator)
				);
		System.out.println("element located");
		return element;
	}
	catch(Exception e)
	{
		System.out.println("Element not located");
		
	}
	return null;
}


}
