package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class wedriver_wait 
{
	static WebDriver dr;
	static WaitTypes wt;
	public wedriver_wait(WebDriver dr)
	{
		this.dr=dr;
	}
	public static void login(String uid,String pwd)
	{
		wt=new WaitTypes(dr);
		String a_result;
		/*System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");*/
		
		By by_eid=By.xpath("//input[@class='email']");
		WebElement we_eid= wt.waitforElement(by_eid,20);
		we_eid.sendKeys(uid);
		
		By by_pwd=By.xpath("//input[@class='password']");
		WebElement we_pwd=wt.waitforElement(by_pwd,20);
		we_pwd.sendKeys(pwd);
		
		By by_btn=By.xpath("//input[@value='Log in']");
		WebElement we_btn=wt.waitforElement(by_btn,20);
		we_btn.click();
	}

}
