package WEBDRIVER_BASICS;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class demoaccessories {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner s4= new Scanner(System.in);
		System.out.println("Enter the number");
		int p=s4.nextInt();
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr= new ChromeDriver();
		String k="tirumalashetty.harika@gmail.com";
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys("tirumalashetty.harika@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("anjaneya9$");
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[2]/a")).click();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[1]/div[1]/div[2]/ul/li[2]/ul/li[3]/a")).click();
		String s= dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
		//String s1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		//System.out.println(s1);
		//String s2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		//System.out.println(s2);
		String l="//div[@class='product-grid']//child::div["+p+"]";
		String s3=dr.findElement(By.xpath(l)).getText();
		System.out.println(s3);
		int k1=p;
		String l2="//div[@class='item-box']["+k1+"]//child::input";
		dr.findElement(By.xpath(l2)).click();

		dr.findElement(By.xpath("//div[@class='header-links']//child::li[3]")).click();
		dr.findElement(By.xpath("//td[@class='remove-from-cart']//child::input")).click();
		dr.findElement(By.xpath("//div[@class='common-buttons']//child::input")).click();

	}

}
