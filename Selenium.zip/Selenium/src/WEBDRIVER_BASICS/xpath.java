package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class xpath {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		String t="tirumalashetty.harika@gmail.com";
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		int p=1;
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys("tirumalashetty.harika@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("anjaneya9$");
		
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[4]/div[2]/div/div[2]/div[1]/div[2]/div[2]/form/div[5]/input")).click();
		//String s1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		//System.out.println(s1);
		//String s2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		//System.out.println(s2);
		String l="//div[@class='product-grid']//child::div["+p+"]";
String s3=dr.findElement(By.xpath(l)).getText();
int k1=p;
String l1="//div[@class='item-box']["+k1+"]//child::input";
dr.findElement(By.xpath(l1)).click();
//int m=s.compareTo(k1);
//if(m==0)
//{
	//System.out.println("pass");
//}



	}

}
