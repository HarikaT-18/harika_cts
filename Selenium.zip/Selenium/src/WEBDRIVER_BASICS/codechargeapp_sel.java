package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class codechargeapp_sel
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/RegistrationForm/Registration.php");
		dr.findElement(By.xpath("//input[@name='user_login']")).sendKeys("b");
		dr.findElement(By.xpath("//input[@name='user_password']")).sendKeys("bluelotus");
				dr.findElement(By.xpath("//input[@name='first_name']")).sendKeys("harika");		
		dr.findElement(By.xpath("//input[@name='last_name']")).sendKeys("tirumalasetty");
		dr.findElement(By.xpath("//input[@name='email']")).sendKeys("tirumalashetty.harika@gmail.com");
		dr.findElement(By.xpath("//input[@name='address1']")).sendKeys("Elcot");
		dr.findElement(By.xpath("//input[@name='city']")).sendKeys("chennai");
		dr.findElement(By.xpath("//select[@name='state_id']//child::option[18]")).click();
		dr.findElement(By.xpath("//input[@name='zip']")).sendKeys("51750");
		dr.findElement(By.xpath("//select[@name='country_id']//child::option[113]")).click();
		dr.findElement(By.xpath("//input[@name='phone_home']")).sendKeys("234567189");
		dr.findElement(By.xpath("//input[@name='phone_work']")).sendKeys("1234567892");
		dr.findElement(By.xpath("//select[@name='language_id']//child::option[2]")).click();
		dr.findElement(By.xpath("//select[@name='age_id']//child::option[3]")).click();
		dr.findElement(By.xpath("//select[@name='gender_id']//child::option[2]")).click();
		dr.findElement(By.xpath("//select[@name='education_id']//child::option[3]")).click();
		dr.findElement(By.xpath("//select[@name='income_id']//child::option[4]")).click();
		dr.findElement(By.xpath("//input[@value='Register']")).click();
		 dr.findElement(By.xpath("//input[@name='s_keyword']")).sendKeys("harika");
		 String s1=dr.findElement(By.xpath("//input[@name='s_keyword']")).getText();
		
		String s2="harika";
		if(s1==s2)
		{
			System.out.println("Registration successful");
		}
		else
		{
			System.out.println("Registration unsuccessful");
		}
		dr.findElement(By.xpath("//input[@value='Search']")).click();

	}

}
