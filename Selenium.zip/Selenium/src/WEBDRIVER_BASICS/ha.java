package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ha {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		String t="tirumalashetty.harika@gmail.com";
		WebDriver dr=new ChromeDriver();
	
		dr.get("http://demowebshop.tricentis.com");
		//dr.findElement(By.linkText("Log1")).click();
		
		//dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		//dr.findElement(By.id("Email")).sendKeys("tirumalashetty.harika@gmail.com");
		//dr.findElement(By.id("Password")).sendKeys("anjaneya9$");
		//dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click(); 
		String xp="/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[2]/a1";
		WebElement we;
		WebDriverWait wt=new WebDriverWait(dr,20);
		we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath(xp)));
		we.click();
		

	}

}
