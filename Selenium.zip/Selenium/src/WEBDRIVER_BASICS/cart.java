package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class cart {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		String t="tirumalashetty.harika@gmail.com";
		WebDriver dr=new ChromeDriver();
	
		dr.get("http://demowebshop.tricentis.com");
		
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys("tirumalashetty.harika@gmail.com");
		dr.findElement(By.id("Password")).sendKeys("anjaneya9$");
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[3]")).click();
		dr.findElement(By.xpath("//table[@class='cart']//child::tr[1]"));
		
		dr.findElement(By.xpath("//tr[@class='cart-item-row']//child::input[1]")).click();
		dr.findElement(By.xpath("//table[@class='cart']//child::tr[1]"));
		dr.findElement(By.xpath("//table[@class='cart']//child::tr[2]"));
		dr.findElement(By.xpath("//td[@class='qty nobr']//child::input")).clear();
		dr.findElement(By.xpath("//td[@class='qty nobr']//child::input")).sendKeys("2");
		
		dr.findElement(By.xpath("//div[@class='common-buttons']//child::input[1]")).click();
		// String s1="//tr[@class='cart-item-row']//child::td[5]";
		// dr.findElement(By.xpath(s1)).getText();
		

	}

}
