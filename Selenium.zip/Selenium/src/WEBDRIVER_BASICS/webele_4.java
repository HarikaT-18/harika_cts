package WEBDRIVER_BASICS;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class webele_4 

{
	static String str;
	
	public void extract()
	
	{
		int p1=str.indexOf(":",1);
		int p2=str.indexOf("A");
		int p3=str.indexOf("p");
		 String s1= str.substring(p1+2,p2-1);
		 String s2=str.substring(p3+2);
		 System.out.println(s1);
		 System.out.println(s2);
	
	}

	
	public static void main(String[] args)
	
	{
		// TODO Auto-generated method stub
		String s1="female";
		String s2="5-10";
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.seleniumeasy.com/test/basic-radiobutton-demo.html");
		webele_4 e=new webele_4();
		
		/* String xp="//*[@id='easycont']/div/div[2]/div[2]/div[2]/p[2])";
		String str=dr.findElement(By.xpath(xp)).getText();
		System.out.println(str);*/
		
		List rb=dr.findElements(By.name("gender"));
		((WebElement) rb.get(1)).click();
		List rb1=dr.findElements(By.name("ageGroup"));
		((WebElement) rb1.get(1)).click();
		dr.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[2]/div[2]/button")).click();
		e.str=dr.findElement(By.className("groupradiobutton")).getText();
		System.out.println(e.str);
	     e.extract();
		//if(s1==s3)
		{
			System.out.println("pass");
		}
		//else
			System.out.println("fail");
		
	
		
		

	}

}
