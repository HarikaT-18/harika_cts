package WEBDRIVER_BASICS;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystemException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class excelread_sel
{
	
	public String read_excel(String f_name,String s_name,int r,int c)
	
	{
		File f=new File(f_name);
        String s1=null;
        try
        {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(s_name);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.getCell(c);
			 s1=cell.getStringCellValue();	                                                                                                                                                                                                                                     		
								
		} catch (FileSystemException e) {
			// TODO Auto-generated catch block                                                         
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s1; 	
	}
	  public void writedata(String finame,String sname,int r,int c,String data)
      {
     	  try
           {
          	 File f=new File(finame);
  			FileInputStream fis=new FileInputStream(f);
  			XSSFWorkbook wb=new XSSFWorkbook(fis);
  			XSSFSheet sh=wb.getSheet(sname);
  			XSSFRow row=sh.getRow(r);
  			XSSFCell cell=row.createCell(c);
  			 cell.setCellValue(data);
  			 FileOutputStream fos=new FileOutputStream(f);
  			 wb.write(fos);
           } 
     	  catch (FileNotFoundException e) 
   		{
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
            catch (IOException e)
            {
   			// TODO Auto-generated catch block
   			e.printStackTrace();
   		}
      }

	public String login(String eid,String pwd)
	{
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
        dr.findElement(By.id("Email")).sendKeys(eid);
	    dr.findElement(By.id("Password")).sendKeys(pwd);
	    dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	    String s1=dr.findElement(By.xpath("/html/body/div[4]/div[1]/div[1]/div[2]/div[1]/ul/li[1]/a")).getText();
	    dr.close();
	    return s1;
	}

	public static void main(String[] args)
	{
		// TODO Auto-generated metho	
		excelread_sel e1=new excelread_sel();
		String test_result;
		for(int r1=0;r1<=2;r1++)
		{
		String s=e1.read_excel("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\excel1.xlsx","Sheet1",r1,0);
		String s1=e1.read_excel("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\excel1.xlsx","Sheet1",r1,1);
		String act_result=e1.login(s, s1);
		String exp_emailid=e1.read_excel("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\excel1.xlsx","Sheet1",r1,2);
		e1.writedata("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\excel1.xlsx","Sheet1",r1,3,act_result);
		
	if(exp_emailid. equals (act_result)==true)
	{
		test_result="PASS";
	}
	else
	{
		test_result="FAIL";
	}	
		e1.writedata("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\excel1.xlsx","Sheet1",r1,4,test_result);
		}
		
	}
        
}
