package WEBDRIVER_BASICS;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

public class beforemethod_testng
{ 
	login_testng e;
	@BeforeMethod
	  public void beforeMethod()
	  {
		  //System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			//WebDriver dr=new ChromeDriver();
			//dr.get("http://demowebshop.tricentis.com");
 e=new login_testng();
	  }
  @Test
  public void t1() 
  {
	  System.out.println("in test method t1");
	  e.login();
	  
  }
  @Test
  public void t2() 
  {
	  System.out.println("in test method t2");
	  e.login();
  }
 
  
  

}
