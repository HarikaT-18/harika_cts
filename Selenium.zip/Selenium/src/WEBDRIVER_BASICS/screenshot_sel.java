package WEBDRIVER_BASICS;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class screenshot_sel 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		dr.findElement(By.xpath("//div[@class='login-box']//child::input[1]")).sendKeys("standard_user");
		dr.findElement(By.xpath("//div[@class='login-box']//child::input[2]")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//div[@class='login-box']//child::input[3]")).click();
		File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
		File f2=new File("C:\\Users\\BLTuser.BLT0211\\Desktop\\Harika\\scr.png");
		try {
			FileUtils.copyFile(f1, f2);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
