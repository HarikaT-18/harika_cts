package WEBDRIVER_BASICS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class sauce_sel
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub

		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		String n1name="",n2name="",price1="",price2="";
		dr.findElement(By.xpath("//div[@class='login-box']//child::input[1]")).sendKeys("standard_user");
		dr.findElement(By.xpath("//div[@class='login-box']//child::input[2]")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//div[@class='login-box']//child::input[3]")).click();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		n1name=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name'][1]")).getText();
		n2name=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name'][2]")).getText();
		price1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price'][1]")).getText();
		price2=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price'][2]")).getText();

		System.out.println(n1name);
		System.out.println(n2name);
		System.out.println(price1);
		System.out.println(price2);
		
		dr.findElement(By.xpath("//div[@class='inventory_list']//following::button[1]")).click();
		dr.findElement(By.xpath("//div[@class='inventory_list']//following::button[2]")).click();

		dr.findElement(By.xpath("//div[@class='shopping_cart_container']//child::a[1]")).click();
		String a_p1name=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][1]")).getText();
		String a_p2name=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][2]")).getText();
		String a_price1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][1]")).getText();
		String a_price2=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][2]")).getText();

		if(n1name.equals(a_p1name)&& n2name.equals(a_p2name))
		System.out.println("Products name are matched");
		else
		System.out.println("Products name are not matched");
		if(price1.substring(1).equals(a_price1)&&price2.substring(1).equals(a_price2))
		System.out.println("Products prices are matched");
		else
		System.out.println("Products prices are not matched");

	}

}
