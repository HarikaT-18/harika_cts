package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class application_sel
{

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://examples.codecharge.com/store/Default.php");
		String s=dr.getTitle();
		String s1="Online Bookstore";
		System.out.println(s);
		if(s1.equals(s)==true)
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
		WebElement we=dr.findElement(By.name("category_id"));
		//dr.getTitle((By.xpath("//font[@style="font-family: Arial; font-size: 26 px;"]));
		Select sel=new Select(we);
		sel.selectByVisibleText("Databases");
		dr.findElement(By.xpath("//input[@name='DoSearch']")).click();
		//dr.findElement(By.xpath("//td[@valign="top"]//child::h1"));
		dr.findElement(By.xpath("//a[@href='ProductDetail.php?product_id=1']")).click();
		
		String w=dr.findElement(By.xpath("//td[@colspan='2']")).getText();
		System.out.println(w);
		dr.findElement(By.xpath("//input[@maxlength='7']")).clear();
		dr.findElement(By.xpath("//input[@maxlength='7']")).sendKeys("2");
		dr.findElement(By.xpath("//input[@name='Insert1']")).click();
		String v=dr.findElement(By.xpath("/html/body/table[5]/tbody/tr/td/table/tbody/tr/td/p")).getText();
		if(w==v)
		{
			System.out.println(w);
		}
		else
		{
			System.out.println(v);
		}
				
		
		
		
		
		

	}

}
