package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystemException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Login_va_inva_sel
{

	public String read_excel(String f_name,String s_name,int r,int c)
	
	{
		File f=new File(f_name);
        String s1=null;
        try
        {
			FileInputStream fis=new FileInputStream(f);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			XSSFSheet sh=wb.getSheet(s_name);
			XSSFRow row=sh.getRow(r);
			XSSFCell cell=row.getCell(c);
			 s1=cell.getStringCellValue();	                                                                                                                                                                                                                                     		
								
		} catch (FileSystemException e) {
			// TODO Auto-generated catch block                                                         
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return s1; 	
	}
	
	 public void writedata(String finame,String sname,int r,int c,String act_res)
     {
    	  try
          {
         	 File f=new File(finame);
 			FileInputStream fis=new FileInputStream(f);
 			XSSFWorkbook wb=new XSSFWorkbook(fis);
 			XSSFSheet sh=wb.getSheet(sname);
 			XSSFRow row=sh.getRow(r);
 			XSSFCell cell=row.createCell(c);
 			 cell.setCellValue(act_res);
 			 FileOutputStream fos=new FileOutputStream(f);
 			 wb.write(fos);
          } 
    	  catch (FileNotFoundException e) 
  		{
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
           catch (IOException e)
           {
  			// TODO Auto-generated catch block
  			e.printStackTrace();
  		}
     }
	 public String login(String eid,String pwd)
	 {
		 System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			WebDriver dr=new ChromeDriver();
			dr.get("http://demowebshop.tricentis.com");
			dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
			dr.findElement(By.id("Email")).sendKeys(eid);
			dr.findElement(By.id("Password")).sendKeys(pwd);
			//dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
			dr.findElement(By.xpath("//div[@class='returning-wrapper']//following::input[5]")).click();
			String s1;
			s1=dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]")).getText();
			if(eid.contains("@gmail.com")==true)
			{
				
						if(s1.equals("Register"))
						{
							s1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']")).getText();
						}
			}
			else
			{
				s1=dr.findElement(By.xpath("span[@class='field-validation-error']//child::span")).getText();
			}
			
			//String s1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
			//String s2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
			//String s3=s1.concat(s2);
			//return s3;
			dr.close();
			dr.quit();
			return s1;
	
	 }
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		 Login_va_inva_sel e=new  Login_va_inva_sel();
		String link="C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\excel1.xlsx";
		String s="Sheet2";
		String test_res,p,q,act_res = null,exp_res = null;
		int r;
		for(r=0;r<=3;r++)
		{
			 p=e.read_excel(link, s, r, 0);
			 q=e.read_excel(link, s, r, 1);
		 act_res=e.login(p,q);
			 exp_res=e.read_excel(link, s, r, 2);
		
		
		if(exp_res.equals(act_res)==true)
		{
			test_res="PASS";
		}
		else
		{
			test_res="fAIL";
		}
		e.writedata(link, s, r, 3, act_res);
		e.writedata(link,s,r,4,test_res);
		}

	}

}
