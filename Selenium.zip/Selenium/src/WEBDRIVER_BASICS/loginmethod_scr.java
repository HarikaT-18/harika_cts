package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public  class loginmethod_scr
{
	
	
	public void login(String eid,String pwd)
	{
	System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	WebDriver dr=new ChromeDriver();
	dr.get("http://demowebshop.tricentis.com");
				dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
				dr.findElement(By.id("Email")).sendKeys(eid);
				dr.findElement(By.id("Password")).sendKeys(pwd);
				//dr.findElement(By.xpath("//div[@class='inputs']//child::input")).click();
				//dr.findElement(By.xpath("//div[@class='inputs']//child::input[1]")).click();
				dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
	}
	
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		loginmethod e3=new loginmethod();
		e3.login("tirumalashetty.harika@gmail.com","anjaneya9$" );
		

	}

}
