package WEBDRIVER_BASICS;

import org.openqa.selenium.By;

public class login_testng
{
public void login()
{
	System.out.println("Login successful");
}
}
