package WEBDRIVER_BASICS;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystemException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;

public class sauceapp_sel
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		sauceapp_sel e=new sauceapp_sel();
		
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
		String n1name="",n2name="",price1="",price2="";//String link ="C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\sauce.xlsx";
		//String g="Sheet1";
		//String u=e.read_excel(link,g,0,0);
		//String v=e.read_excel(link,g,0,1);
		try
		{
		dr.findElement(By.xpath("//input[@type='text']")).sendKeys("standard_user");
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//input[@type='submit']")).click();
		dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		n1name=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name'][1]")).getText();
		n2name=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name'][2]")).getText();
		price1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price'][1]")).getText();
		price2=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price'][2]")).getText();

		System.out.println(n1name);
		System.out.println(n2name);
		System.out.println(price1);
		System.out.println(price2);
		
		dr.findElement(By.xpath("//div[@class='inventory_list']//following::button[1]")).click();
		dr.findElement(By.xpath("//div[@class='inventory_list']//following::button[2]")).click();

		dr.findElement(By.xpath("//div[@class='shopping_cart_container']//child::a[1]")).click();
		}
		catch(WebDriverException e1)
		{

		}
		String a_p1name=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][1]")).getText();
		String a_p2name=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][2]")).getText();
		String a_price1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][1]")).getText();
		String a_price2=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][2]")).getText();
		//String e_p1=dr.findElement(By.xpath("//div[@class='inventory_list']//div[1][@class='inventory_item']//div[@class='inventory_item_price']")).getText();
		//String e_p2=dr.findElement(By.xpath("//div[@class='inventory_list']//div[2][@class='inventory_item']//div[@class='inventory_item_price']")).getText();
		
		if(n1name.equals(a_p1name)&& n2name.equals(a_p2name))
		System.out.println("Products name are matched");
		else
		System.out.println("Products name are not matched");
		if(price1.substring(1).equals(a_price1)&&price2.substring(1).equals(a_price2))
		System.out.println("Products prices are matched");
		else
		System.out.println("Products prices are not matched");
	
	}
}
		
		
		
