package WEBDRIVER_BASICS;

import org.testng.annotations.Test;

public class new_testng1 {
  @Test
  public void t1() 
  {
	  System.out.println("in test method t1");
	  t2();
  }
  
  public void t2() 
  {
	  System.out.println("in test method t2");
  }
  
  public void t3() 
  {
	  System.out.println("in test method t3");
  }
}
