package WEBDRIVER_BASICS;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class invalid_login
{
 public String login_inv(String eid,String pwd)
 {
	 System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[2]")).click();
		dr.findElement(By.id("Email")).sendKeys(eid);
		dr.findElement(By.id("Password")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@class='button-1 login-button']")).click();
		String s1=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::span")).getText();
		String s2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		String s3=s1.concat(s2);
		return s3;
	 
 }
	public static void main(String[] args)
	{
		// TODO Auto-generat
		invalid_login e1=new invalid_login();
		String exp_em="Login was unsuccessful. Please correct the errors and try again.The credentials provided are incorrect";
				      			       
		String act_em= e1.login_inv("tirumalashetty.harika@gmail1.com", "anjaneya9$");
		//String act_em1= e1.login_inv("tirumalashetty.harika@gmail.com", "anjaneya9");
		//String act_em2= e1.login_inv("tirumalashetty.harika@gmail.com", " ");
		System.out.println(act_em);
		if(exp_em.equals(act_em)==true)
		{
			System.out.println("PASS");
		}
		else
			System.out.println("FAIL");		

	}

}
