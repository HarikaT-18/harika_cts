package Test_NG;


import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class NewTest 
{
	
		ChromeDriver dr;
		example_ng e;
		 @BeforeMethod
		  public void beforeMethod()
		  {
			  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
			  dr=new ChromeDriver();
			  dr.get("https://www.saucedemo.com/");
			  e=new example_ng(dr);
			  
		  }
	  @Test
	  public void f1() 
	  {
		  e.login1("standard_user", "secret_sauce");
	  }

}
