package Test_NG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.asserts.SoftAssert;

public class sa_demo
{
	WebDriver dr;
	 sauce_demo e= new sauce_demo();
	 int p[]={1,2};
	 int i=0;
  @Test
  public void t1()
  {
	  //e.verify(1);
	  String a_n1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][1]")).getText();
	 // String a_p1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][1]")).getText();
	  String a_p1="8.9";
	  SoftAssert sa=new SoftAssert ();
	  sa.assertEquals(e.exp_n1, a_n1);
	  sa.assertAll();
	  System.out.println(a_n1);
	  System.out.println(a_p1);			  
  }
  @Test
  public void t2()
  {
	  //String a_n1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_name'][1]")).getText();
	  String a_n1="Sauce Backpack";
	  String a_p1=dr.findElement(By.xpath("//div[@class='cart_list']//following::div[@class='inventory_item_price'][2]")).getText();
	  SoftAssert sa=new SoftAssert ();
	  sa.assertEquals(e.exp_p1.substring(1),a_p1);
	  sa.assertAll();
	  System.out.println(a_n1);
	  System.out.println(a_p1);		
  }
  @BeforeMethod
  public void beforeMethod()
  {
	 
	  e.add_pro(p[i]);
	 
  }

  @BeforeClass
  public void beforeClass()
  {
	 
	 dr= e.la_br("standard_user","secret_sauce");
  }
  @AfterMethod
  public void afterMethod()
  {
	  if(i<1)
	  {
		  dr.findElement(By.xpath("//div[@class='cart_footer']//child::a[1]")).click();
	  }
		
	  else
	  {
		  dr.findElement(By.xpath("//div[@class='cart_footer']//child::a[2]")).click();
	  }
	  i++;
  }
  @AfterClass
  public void afterClass()
  {
	  e.add_info();
  }

}  
