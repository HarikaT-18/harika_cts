package Test_NG;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class sauce_demo
{
	WebDriver dr;
	String a_n1=null,a_p1=null;
	String exp_n1=null,exp_p1=null;
	int count;
	public WebDriver la_br(String eid,String pwd)
	{

		  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		  dr=new ChromeDriver();
		  dr.get("https://www.saucedemo.com/");
		  dr.findElement(By.xpath("//input[@type='text']")).sendKeys(eid);
			dr.findElement(By.xpath("//input[@type='password']")).sendKeys(pwd);
			dr.findElement(By.xpath("//input[@type='submit']")).click();
			return dr;
	}
	public void add_pro(int n)
	{
		//dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		/*WebDriverWait wt=new WebDriverWait(dr,10);
		WebElement we;
		we=wt.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class='inventory_list']//following::button["+n+"]")));
		we.click();
		 count++;
		System.out.println(count);*/
		
		exp_n1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_name']["+n+"]")).getText();
		exp_p1=dr.findElement(By.xpath("//div[@class='inventory_list']//following::div[@class='inventory_item_price']["+n+"]")).getText();
		
	    dr.findElement(By.xpath("//div[@class='inventory_list']//following::button["+n+"]")).click();
		dr.findElement(By.xpath("//div[@class='shopping_cart_container']//child::a[1]")).click();
		//System.out.println(exp_n1);
		//System.out.println(exp_n1);
		
		
	}
	/*public void verify(int n)
	{
		
		try
		{
			
		
		
		}
		catch(WebDriverException e)
		{
			
		}
		*/
		
		
		
		/*if (exp_n1.equals(a_n1))
		{
			System.out.println("product names are matched");
		}
		else
		{
			System.out.println("product names are not matched");
		}
		if(exp_p1.substring(1).equals(a_p1))
		{
			System.out.println("product prices are matched");
		}
		else
		{
			System.out.println("Product prices are not matched");
		}*/
		
	
	
	public void add_info()
	{
		dr.findElement(By.xpath("//div[@class='checkout_info']//input[1]")).sendKeys("h");
		dr.findElement(By.xpath("//div[@class='checkout_info']//input[2]")).sendKeys("t");
		dr.findElement(By.xpath("//div[@class='checkout_info']//input[3]")).sendKeys("517");
		dr.findElement(By.xpath("//div[@class='checkout_buttons']//input[1]")).click();
		dr.findElement(By.xpath("//div[@class='cart_footer']//a[2]")).click();
	}

}
