package Test_NG;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class assert_sel {
  @Test
  public void t1() 
  {
	  String er="bangalore";
	  String ar="bangalore";
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
  }
  @Test
  public void t2() 
  {
	  String er="bangalore";
	  String ar="bangalore1";
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(er, ar);
	  sa.assertAll();
  }
  
}
