package Test_NG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;

public class NewTest1
{
	WebDriver dr;
	String s="https://www.saucedemo.com/";
  @Test
  public void f()
  {

		dr.findElement(By.xpath("//input[@type='text']")).sendKeys("standard_user");
		dr.findElement(By.xpath("//input[@type='password']")).sendKeys("secret_sauce");
		dr.findElement(By.xpath("//input[@type='submit']")).click(); 
  }
  @BeforeMethod
  public void beforeMethod()
  {
	  System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
	  dr=new ChromeDriver();
	  dr.get("https://www.saucedemo.com/");
	  
  }

  @AfterMethod
  public void afterMethod()
  {
	  dr.close();
  }

}
