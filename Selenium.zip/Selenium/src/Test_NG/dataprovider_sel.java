package Test_NG;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.asserts.SoftAssert;

public class dataprovider_sel
{ 
	dataprovider_login e=new dataprovider_login();
	
  @Test(dataProvider = "login_data")
  public void login(String eid , String pwd,String e_eid) 
  {
	  
	  String a_eid=e.login1(eid,pwd);
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(a_eid,e_eid);
	  sa.assertAll();
	  System.out.println(e_eid);
	  
	  //System.out.println(" email :  "  +eid+ "  pwd : " +pwd);
  }

  @DataProvider(name="login_data")
  public String[][] provide_data()  
  {
   String[][] data= {
       { "tirumalashetty.harika@gmail.com", "anjaneya9$","tirumalashetty.harika@gmail.com" },
      // { "a2", "p2" },
    };
    return data;
  }
}
