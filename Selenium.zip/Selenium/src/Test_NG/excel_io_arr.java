package Test_NG;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystemException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel_io_arr

{
	public static String filename="C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\sel.xlsx";
	public static String sheetname="login_data";
	public static String[][] testdata;
	public static int r, c;
	
	public static void get_data()
	{
		testdata=new String[2][3];
		int c;
		String s=null,s1=null,s2=null;
		for(r=1;r<=2;r++)
		{
        try
        {
        	System.out.println(" in get data row = " +r);
        
			FileInputStream fis=new FileInputStream(filename);
			XSSFWorkbook wb=new XSSFWorkbook(fis);
			String s_name = null;
			XSSFSheet sh=wb.getSheet(sheetname);
			int r=0;
			XSSFRow row=sh.getRow(r);
			int c1=0;
			XSSFCell cell=row.getCell(c1);
			 s1=cell.getStringCellValue();	                                                                                                                                                                                                                                     		
								
		} catch (FileSystemException e) {
			// TODO Auto-generated catch block                                                         
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
}
