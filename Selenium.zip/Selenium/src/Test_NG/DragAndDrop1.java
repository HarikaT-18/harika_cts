package Test_NG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop1
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("https://demoqa.com/droppable/");
		dr.manage().window().maximize();
		Actions builder=new Actions(dr);
		//WebElement from=dr.findElement(By.xpath("//div[@class='ui-widget-content ui-draggable ui-draggable-handle']"));
		WebElement from=dr.findElement(By.id("draggable"));
		WebElement to=dr.findElement(By.id("droppable"));
		//WebElement to=dr.findElement(By.xpath("//div[@class='ui-widget-header ui-droppable']"));
		builder.dragAndDrop(from, to).perform();
		String textTo=to.getText();
		if(textTo.equals("Dropped!"))
		{
			System.out.println("PASS: drag & drop successful");
		}
		else
		{
			System.out.println("FAIL: drag & drop not successful");
		}

	}

}
