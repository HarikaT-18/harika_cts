package Test_NG;

import org.testng.annotations.Test;

public class priorityex_sel 
{
  @Test(priority=0)
  public void t1() 
  {
	  System.out.println("in test method t1");
  }
  @Test(priority=5)
  public void t2() 
  {
	  System.out.println("in test method t2");
  }
  @Test(priority=3)
  public void t3() 
  {
	  System.out.println("in test method t3");	
  }
}
