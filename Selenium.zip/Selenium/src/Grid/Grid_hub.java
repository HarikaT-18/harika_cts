package Grid;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

public class Grid_hub

{
	WebDriver dr;
	String auturl,nodeurl;
		
  @Test
  public void f()
  {
	  dr.quit();
  }
  @Test
  public void f1()
  {
	  dr.get(auturl);
  }
  
  @BeforeClass
  public void setup() throws MalformedURLException
  
  {
	  auturl="http://demowebshop.tricentis.com";
	  nodeurl="http://192.168.43.125:5566/wd/hub";
	  DesiredCapabilities cap= DesiredCapabilities.chrome();
	  cap.setBrowserName("chrome");
	  cap.setPlatform(Platform.WINDOWS);
	  dr=new RemoteWebDriver(new URL(nodeurl),cap);
	   
	  
	  
  }                                                                                                                                                                                                  

}
