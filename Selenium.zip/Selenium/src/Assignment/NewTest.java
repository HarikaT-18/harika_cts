package Assignment;

import java.io.IOException;

import javax.imageio.IIOException;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.asserts.SoftAssert;

public class NewTest extends as_1

{
	
	
  @Test(dataProvider = "dp")
  public void calllogin(String f_name, String l_name,String e,String p,String c) throws Exception 
  
  {
	  String A_result=reg(f_name,l_name,e,p,c);
	
	  String E_Results="Your registration completed";
	  SoftAssert sa=new SoftAssert();
	  sa.assertEquals(A_result, E_Results);
	  sa.assertAll();


  }
 
  
  @DataProvider(name="dp")
  public String[][] provide_data()
  {
    return  testdata; 
     
    }
  
  @BeforeClass
  public void beforeClass()
  {
	  get_excel1();
  }
 
 
}
