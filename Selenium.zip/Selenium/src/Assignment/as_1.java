package Assignment;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class as_1
{	
	private static final TakesScreenshot dr = null;
	static String[][] testdata=new String[2][5];
	static int count=0;
			
  public static String reg(String f_n,String l_n,String eid,String pwd,String c_pwd)throws IOException
		
{	

		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		WebDriver dr=new ChromeDriver();
		dr.get("http://demowebshop.tricentis.com");
		dr.findElement(By.xpath("//div[@class='header-links']//child::li[1]")).click();
		List rb=dr.findElements(By.name("radio"));
		((WebElement)rb.get(0)).click();
		dr.findElement(By.xpath("//input[@name='FirstName']")).sendKeys(f_n);
		dr.findElement(By.xpath("//input[@name='LastName']")).sendKeys(l_n);
		dr.findElement(By.xpath("//input[@name='Email']")).sendKeys(eid);
		dr.findElement(By.xpath("//input[@name='Password']")).sendKeys(pwd);
		dr.findElement(By.xpath("//input[@name='ConfirmPassword']")).sendKeys(c_pwd);

		dr.findElement(By.xpath("//input[@name='register-button']")).click();
		String match=dr.findElement(By.xpath("//a[@href='/customer/info']")).getText();
		Takescreenshot(count);
		if(match.equals(eid))
		{

		String s1=dr.findElement(By.xpath("//div[@class='result']")).getText();
		return s1;
		}
		else
		{
		String s2=dr.findElement(By.xpath("//div[@class='validation-summary-errors']//child::li")).getText();
		System.out.println(s2);
		return s2;
		}
		//
		// dr.close();

		}



		

  public static void get_excel1()
  
  {  
	  int r=0,c= 0;
	
	  try
      {
		 File f =new File("C:\\Users\\BLTuser.BLT0211\\Desktop\\cts\\sel.xlsx");		 		  
         FileInputStream fis=new FileInputStream(f);
		 XSSFWorkbook wb=new XSSFWorkbook(fis);
		 XSSFSheet sh=wb.getSheet("Sheet1");
			for(r=0;r<=1;r++)
			{
				XSSFRow R=sh.getRow(r);
				for(c=0;c<=4;c++)
				{
					XSSFCell C=R.getCell(c);
					testdata[r][c]=C.getStringCellValue();
				}
			}								
		}
	     catch (FileNotFoundException e)
		{
			// TODO Auto-generated catch block                                                         
			e.printStackTrace();
		} 
	  catch (IOException e)
	  {
			// TODO Auto-generated catch block
			e.printStackTrace();
	  }
	
  }
  
  public static void Takescreenshot(int count2) throws IOException
  {
  // TODO Auto-generated method stub
  if(count2==1)
  {
  File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
  File f2=new File("C:\\Users\\BLTuser.BLT0211\\Desktop\\Harika\\1.png");
  FileUtils.copyFile(f1, f2);
  }
  else
  {
  File f1=((TakesScreenshot)dr).getScreenshotAs(OutputType.FILE);
  File f2=new File("C:\\Users\\BLTuser.BLT0211\\Desktop\\Harika\\2.png");
  FileUtils.copyFile(f1, f2);}
  }
  }
  
  
	
    

  
  
  
  

				
		


		
