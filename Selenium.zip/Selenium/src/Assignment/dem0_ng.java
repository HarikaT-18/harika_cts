package Assignment;

import java.io.IOException;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeClass;
import org.testng.asserts.SoftAssert;

public class dem0_ng extends demo_sel
{
  
@Test(dataProvider = "dp")
  public void login(String FirstName , String LastName,String Email,String Password,String cp)
  {
	String E_Results="Your registration completed";
	  try {
	String  A_Results=DemoRegister(FirstName,LastName,Email,Password);
		 SoftAssert sa=new SoftAssert();
		  
		sa.assertEquals(E_Results, A_Results);
		  sa.assertAll() ;
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }

  @DataProvider(name="dp")
  public String[][] dp() 
  {
	  

    return testdata;
      
    
  };
  @BeforeClass
  public void beforeClass()
  {
	  getexcel();
  }

}
