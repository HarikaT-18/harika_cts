package tests;

import org.testng.annotations.Test;

import bookstore.page_1;
import bookstore.page_2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

public class chromebrowser
{
	WebDriver dr;
	
	
  @Test(priority=0)
  public void search_products() 
  {
	  page_1 p1=new page_1(dr);
	  String exp="Online Bookstore";
	  String s=p1.get_title();
	  System.out.println(s);
	  p1.store();
	  Assert.assertEquals(exp,s);
  }
	
  @Test(priority=1)
  public void verification() 
  {
	  page_2 p2=new page_2(dr);
	  String ex="Perl and CGI for the World Wide Web";
	  String s=p2.displayed_title();
	 
	  String s1=p2.bookname();
	  System.out.println(s1);
	  Assert.assertEquals(ex,s1);
			  
			  
  }
  @BeforeClass
  public void beforeClass() 
  {
	  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
	  dr=new ChromeDriver();
	  dr.get("http://examples.codecharge.com/store/Default.php");
	  dr.manage().window().maximize();
  }

}
