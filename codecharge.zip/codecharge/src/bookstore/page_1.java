package bookstore;

import org.apache.poi.hwpf.usermodel.Table;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilites.libraries;

public class page_1 
{
	WebDriver dr;
	
	libraries d=new libraries(dr);

	
	public page_1(WebDriver dr)
	{
		this.dr=dr;
		
	}

	
	By s=By.xpath("//select[@name='category_id']//following::option[2]");
   		
	By btn=By.xpath("//input[@name='DoSearch']");
	public String get_title()
	{
		return dr.getTitle();
	}
	 public  void dropdown()
	 {
		dr.findElement(s).click();
		 
		
		 
	 }
	 public void clk_btn()
	 {
		 dr.findElement(btn).click();
	 }
	 public void store()
	 {
		 this.dropdown();
		 this.clk_btn();
	 }

}
