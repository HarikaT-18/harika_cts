package bookstore;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import utilites.libraries;

public class page_2
{
    WebDriver dr;
	
	libraries d=new libraries(dr);

	public page_2(WebDriver dr)
	{
		this.dr=dr;
		
	}
	
	By b=By.xpath("//a[@href='ProductDetail.php?product_id=3']");
	
	public String displayed_title()
	{
		return dr.getTitle();
	}
	public String bookname()
	{
          String e=dr.findElement(b).getText();
          return e;
	}
	
	
	


}