package PAGES;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilites.libraries;

public class page_2 
{
	WebDriver dr;
	libraries l;
	
	public page_2(WebDriver dr)
	{
		this.dr=dr;
		l=new libraries();		
	}
	
	By email= By.xpath("//form[@class='register']//input[1][@type='email']");
	By password=By.xpath("//form[@class='register']//input[@type='password']");
	By button=By.xpath("//form[@class='register']//input[@type='submit']");
	By uid=By.xpath("//form[@class='login']//input[@name='username']");
	
	

}
