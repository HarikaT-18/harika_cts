package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;

import Pages.AUT_home_page;
import Pages.AUT_login_page;

public class test_AUT_login

{
	WebDriver dr;
	AUT_login_page loginpage;
	AUT_home_page homepage;
  @Test(priority=0)
  public void test_login_page()
  
  {
	  loginpage=new AUT_login_page(dr);
	  String login_page_title=loginpage.get_title();
	  Assert.assertTrue(login_page_title.contains("Shop"));
	  
	  
  }
  @Test(priority=2)
  public void test_home_page()
  
  {
	  loginpage.do_login("tirumalashetty.harika@gmail.com","anjaneya9$");
	  homepage=new AUT_home_page(dr);
	  String actual_eid=homepage.get_display_eid();
	  Assert.assertTrue(actual_eid.contains("tirumalashetty.harika@gmail.com"));
	  
	  
  }
 

@BeforeClass
  public void launchBrowser() 
  {

  System.setProperty("webdriver.chrome.driver", "chromedriver_v79.exe");
  dr=new ChromeDriver();
  dr.get("http://demowebshop.tricentis.com/login");
	  
  }

}
