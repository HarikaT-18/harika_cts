package Tests;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


import pages1.login_page_url;


public class saucedemo
{
	WebDriver dr;
	login_page_url logpage;
  @Test(priority=1)
  public void login_page() 
  {
	  logpage=new login_page_url(dr);
	  logpage.do_login("standard_user","secret_sauce");
	  String login_page_title=logpage.get_title();
	 Assert.assertTrue(login_page_title.contains("Labs"));
	  
  }
  @Test(priority=2)
  public void login_page1() 
  {
	  logpage=new login_page_url(dr);
	  
	  String product_title=logpage.displayed_product();
	 Assert.assertTrue(product_title.contains("Prod"));
	 System.out.println(product_title);
	  
  }
  @Test(priority=2)
  public void products_page() 
  {
	  logpage=new login_page_url(dr);
	  
	  String items_name=logpage.displayed_item();
	 Assert.assertTrue(items_name.contains("pack"));
	 System.out.println(items_name);
	  
  }
  
	  
  @BeforeClass
  public void launchbrowser() 
  {

		System.setProperty("webdriver.chrome.driver","chromedriver_v79.exe");
		 dr=new ChromeDriver();
		dr.get("https://www.saucedemo.com/");
  }

}
