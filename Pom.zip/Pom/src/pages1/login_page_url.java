package pages1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;


public class login_page_url
{
	WebDriver dr;
	
	@FindBy(xpath="//input[@id='user-name']")
	WebElement uid;
	
	@FindBy(xpath="//input[@id='password']")
	WebElement pwd;
	
	@FindBy(xpath="//input[@type='submit']")
	WebElement btn;
	
	@FindBy(xpath="//div[@class='product_label']")
	WebElement pro;
	@FindBy(xpath="//div[@class='inventory_list']//following::div[@class='inventory_item_name'][1]")
	WebElement item;
	
	public login_page_url(WebDriver dr)
	{
		this.dr=dr;
		PageFactory.initElements(dr, this);
	}
	
	public void set_uid(String un)
	{
		uid.sendKeys(un);
	}
	public void set_pwd(String pword)
	{
		pwd.sendKeys(pword);
	}
	public void clk_btn()
	{
		btn.click();
		
	}
	
	public void do_login(String u,String p)
	{
		this.set_uid(u);
		this.set_pwd(p);
		this.clk_btn();
	}
	public String get_title()
	{
		return dr.getTitle();
	}
	public String displayed_product()
	{
		String s=pro.getText();
		return s;
	}
	public String displayed_item()
	{
		String t=item.getText();
		return t;
	}

	
	
	

}
