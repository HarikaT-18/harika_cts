package Utilites;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class libraries 
{
	static WebDriver dr;
	
	public WebElement waitelement(By Locator,int timeout)
	{
		WebElement e=null;
		try
		{
		WebDriverWait wait= new WebDriverWait(dr,timeout);
		 e=wait.until(ExpectedConditions.visibilityOfElementLocated(Locator));
		System.out.println("element located");

		}
		catch(Exception e1)
		{
			
		  System.out.println("element not found"+e1);	
		}
	return e;	
	}
	public WebElement clickable(By Locator, int timeout) 
	{
		WebElement e=null;
		try 
		{
			WebDriverWait wait = new WebDriverWait(dr,timeout);
			e= wait.until(ExpectedConditions.elementToBeClickable(Locator));
			System.out.println("element located");
			return e;
		}
		catch(Exception e1)
		{

			  System.out.println("element not found"+e1);	
		}
		return null;
	}
	
	public static WebDriver launchbrowser(String browser,String url)
	{ 
		String chrome_path="src\\test\\resources\\Driver\\chromedriver_v79.exe";
		String firefox_path="src\\test\\resources\\Driver\\geckodriver.exe";
		if(browser.contains("chrome")) 
		{
			System.setProperty("webdriver.chrome.driver",chrome_path);
			dr= new ChromeDriver();
			
		}else if(browser.contains("firefox")) 
		{
			System.setProperty("webdriver.gecko.driver", firefox_path);
			dr= new FirefoxDriver();
		}
		dr.get(url);
		dr.manage().window().maximize();
		dr.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);

		return dr;	
		}

}
