package com.TestRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

public class Login_Runner 
{
	@CucumberOptions(
			features="src\\main\\resources\\feature",
			tags = {"@TC02_Automation"},
			glue= {"src\\test\\java\\com\\stepdefinition"}
			)
	public class test_runner extends AbstractTestNGCucumberTests 
	{

	}


}
