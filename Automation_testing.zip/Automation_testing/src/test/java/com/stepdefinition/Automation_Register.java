package com.stepdefinition;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Automation_Register 
{
	
	@Given("^the user launch the chrome application$")
	public void the_user_launch_the_chrome_application() throws Throwable
	{
	    
	    throw new PendingException();
	}

	@When("^the user open the  Automation demo Home page$")
	public void the_user_open_the_Automation_demo_Home_page() throws Throwable 
	{
	   
	    throw new PendingException();
	}

	@Then("^the user register using user(\\d+) and passwd$")
	public void the_user_register_using_user_and_passwd(int arg1) throws Throwable 
	{
	   
	    throw new PendingException();
	}

	@Then("^click on the register button user nagivate to the next page$")
	public void click_on_the_register_button_user_nagivate_to_the_next_page() throws Throwable 
	{
	    
	    throw new PendingException();
	}


}
