package com.stepdefinition;

import org.openqa.selenium.WebDriver;

import com.pages.Automation_page1;
import com.pages.Automation_page2;

import Utilites.libraries;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class automation_Login
{
	static WebDriver dr;
	libraries l=new libraries();
	Automation_page1 p1;
	Automation_page2 p2;
	@Given("^user launch the chrome application$")
	public void user_launch_the_chrome_application() throws Throwable
	{
		String url="http://practice.automationtesting.in/";
	   libraries.launchbrowser("chrome", url);
	    throw new PendingException();
	}

	@When("^the user open the  Automation  Home page$")
	public void the_user_open_the_Automation_Home_page() throws Throwable 
	{
		 p1=new Automation_page1(dr);
		 p1.clk_ac();
	    throw new PendingException();
	}

	@Then("^user login using username and password$")
	public void user_login_using_username_and_password(String e,String p) throws Throwable 
	{
	    p2=new Automation_page2(dr);
	    p2.registration(e,p);
	    throw new PendingException();
	}

	@Then("^click on the login button user go to the next page$")
	public void click_on_the_login_button_user_go_to_the_next_page() throws Throwable 
	{
		p2.click();
	    throw new PendingException();
	}

}
