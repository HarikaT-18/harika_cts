package com.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilites.libraries;

public class Automation_page1
{
	WebDriver dr;
	libraries l;
	
	public Automation_page1(WebDriver dr)
	{
		this.dr=dr;
		l=new libraries();
	}
	
    By account =(By.xpath("//ul[@id='main-nav']//li[2]//a"));
    
    public void acc()
    {
    	WebElement we=l.clickable(account, 20);
    	we.click();
    	
    }
    
   public void clk_ac()
   {
	   this.acc();
   }

}
